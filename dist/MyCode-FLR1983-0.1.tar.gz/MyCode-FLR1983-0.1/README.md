# estudospy
Estudos e testes com Python.
